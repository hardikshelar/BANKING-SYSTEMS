package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Admin;
import edu.jsp.Model.Customer;
@WebServlet("/delete")
public class DeleteAccount extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String customerID = req.getParameter("userId");
		PrintWriter writer = resp.getWriter();
		int userId = Integer.parseInt(customerID);
		if(userId!=0) {
			Admin findAdmin = Hibernate_Utility.entityManager.find(Admin.class, 1);
		Customer finduserToDelete = Hibernate_Utility.entityManager.find(Customer.class, userId);
		if(finduserToDelete!=null && findAdmin!=null) {
			Hibernate_Utility.transaction.begin();
			findAdmin.getCustomer().remove(finduserToDelete);
		Hibernate_Utility.entityManager.remove(finduserToDelete);
		Hibernate_Utility.entityManager.merge(findAdmin);
		Hibernate_Utility.transaction.commit();
		writer.println("<html><body>");
        writer.println("<h2>Account has been deleted successfully");
        writer.println("</body></html>");
        resp.sendRedirect("serachUser");
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("user_list.jsp");
        requestDispatcher.include(req, resp);
		}
		
	}
}
}