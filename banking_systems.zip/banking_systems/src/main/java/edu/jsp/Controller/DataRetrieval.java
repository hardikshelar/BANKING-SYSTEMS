package edu.jsp.Controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Customer;
@WebServlet("/serachUser")
public class DataRetrieval extends HttpServlet
{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(req.getParameter("name")!=null) {
		if(req.getParameter("name").equals("userslist")) {
		TypedQuery<Customer> query = Hibernate_Utility.entityManager.createQuery("Select c from Customer c",Customer.class);
		List<Customer> resultList = query.getResultList();
		
		req.setAttribute("resultList", resultList);
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("user_list.jsp");
		requestDispatcher.forward(req, resp);
		}
		}
		else {
			String search = req.getParameter("search");
			List<Customer> resultList = usernameRetrival(search);
			req.setAttribute("resultList", resultList);
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("user_list.jsp");
			requestDispatcher.forward(req, resp);
		}
		
	}
	public static List<Customer> usernameRetrival(String email) {
        TypedQuery<Customer> query = Hibernate_Utility.entityManager
                .createQuery("SELECT e FROM Customer e WHERE e.email = :email", Customer.class);
        query.setParameter("email", email);
        List<Customer> usersList = query.getResultList();
        
        return usersList;
    }

//	
    protected static int generateNewAccountNumber() {
        TypedQuery<Integer> query = Hibernate_Utility.entityManager
                .createQuery("SELECT MAX(c.customerId) FROM Customer c", Integer.class);
        Integer maxCustomerId = query.getSingleResult();
        if (maxCustomerId == null) {
            return 10000100;
        }
        return maxCustomerId + 1;
    }
}

