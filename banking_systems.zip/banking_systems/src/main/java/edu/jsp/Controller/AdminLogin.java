package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Admin;
import edu.jsp.Model.Customer;
@WebServlet(value = "/adminlogin")
public class AdminLogin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		
		String desgn = req.getParameter("designation");
		String password = req.getParameter("password");
		
		HttpSession session = req.getSession();
		
		Admin registeredUser = Hibernate_Utility.entityManager.find(Admin.class, 1);
		PrintWriter writer = resp.getWriter();
		if (registeredUser != null && registeredUser.getAdminId() != 0) {
			if (registeredUser.getEmail().equals(email) && registeredUser.getAdminPass().equals(password)) {

				session.setAttribute("email", email);			
				session.setMaxInactiveInterval(10);

				RequestDispatcher requestDispatcher = req.getRequestDispatcher("bankManager.html");
				requestDispatcher.forward(req, resp);

			} else if (registeredUser.getEmail().equals(email)
					&& !registeredUser.getAdminPass().equals(password)) {
				
				writer.println("<html><body>");
				writer.println("<h2>Incorrect Password!</h2>");
				writer.println("</body></html>");
			}
		} else {
			
			writer.println("<html><body>");
			writer.println("<h2>No User Is Registered With This Credentials! Please Register First</h2>");
			writer.println("</body></html>");
		}
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("adminLogin.html");
		requestDispatcher.include(req, resp);
		
	}
}
