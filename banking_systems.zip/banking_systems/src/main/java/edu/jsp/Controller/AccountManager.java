package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Customer;
@WebServlet(value = "/acManager")
public class AccountManager extends HttpServlet{
	
	public final Map <Integer,Object> accountLocks  = new HashMap();
	private Object getLockforAccount(int Id ) {
		synchronized (accountLocks) {
           if(!accountLocks.containsKey(Id)) {
        	   accountLocks.put(Id, new Object());
           }
           return accountLocks.get(Id);
        }
	}
	//
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		PrintWriter writer = resp.getWriter();
		
		String source = req.getParameter("source");
		final String SdebitAmt = req.getParameter("debit-amount");
		
		String ScreditAmt = req.getParameter("credit-amount");
		String StransferAmt = req.getParameter("transfer-amount");
		String StransferAc = req.getParameter("transfer-account");
		
		HttpSession session = req.getSession();
//		String pass = (String)session.getAttribute("password");
		int cId = (Integer)session.getAttribute("cId");
		Customer findUser = Hibernate_Utility.entityManager.find(Customer.class, cId);
		int balance = findUser.getBalance();
		
		
		
		Hibernate_Utility.transaction.begin();
		
		switch (source) {
		case "debit":
			debitMoney(SdebitAmt, resp, balance, findUser);
			break;
		case "credit":
			creditMoney(ScreditAmt, resp, balance, findUser);
			break;
		case "transfer":
			transferMoney(StransferAmt, StransferAc, resp, balance, findUser);
			break;
		case "checkBal":
			checkBalance(resp, balance);
			break;
		default:
			writer.println("<html><body>");
         writer.println("<h2>Invalid operation.</h2>");
          writer.println("</body></html>");
			break;
		}
//		if(source.equals("debit")) {
//			int debitAmt = Integer.parseInt(SdebitAmt);
//			if(debitAmt!=0) {
//				
//			
//			if(balance>=debitAmt) {
//				balance= balance-debitAmt;
//				findUser.setBalance(balance);
//				writer.println("<html><body>");
//	            writer.println("<script>"
//	                    + "alert(`RS.${balance} DEBITED SUCCESSFULLY from your Account`);" 
//	                    + "</script>");
//	            writer.println("</body></html>");
//	            
//			}
//			else {
//				writer.println("<html><body>");
//				writer.println("<script>"
//	                    + "alert('Insufficient Balance !');" 
//	                    + "</script>");
//				writer.println("</body></html>");
//			}
//		}
//		}
//		else  if(source.equals("credit")) {
//			int creditAmt = Integer.parseInt(ScreditAmt);
//			if(creditAmt!=0) {
//				balance= balance+creditAmt;
//				findUser.setBalance(balance);
//				writer.println("<html><body>");
//	            writer.println("<script>"
//	                    + "alert(`RS.${balance} Credited Successfully in your Account`);" 
//	                    + "</script>");
//	            writer.println("</body></html>");
//			}
//		}
//		else if(source.equals("transfer")) {
//			int transferAmt = Integer.parseInt(StransferAmt);
//			int transferAc = Integer.parseInt(StransferAc);
//			if(transferAmt!=0 && transferAc!=0) {
//				if(balance >=transferAmt) {
//				balance = balance - transferAmt;
//				findUser.setBalance(balance);
//				 Customer findRecipent = Hibernate_Utility.entityManager.find(Customer.class, transferAc);
//				 if(findRecipent!=null) {
//				 int resipentBal = findRecipent.getBalance();
//				 resipentBal = resipentBal+transferAmt;
//				 findRecipent.setBalance(resipentBal);
//				 }
//				 else {
//					 writer.println("<html><body>");
//	                    writer.println("<h2>Recipient account not found.</h2>");
//	                    writer.println("</body></html>");
//				 }
//				}
//				else {
//					writer.println("<html><body>");
//	                writer.println("<h2>Insufficient Balance !</h2>");
//	                writer.println("</body></html>");
//				}
//			}
//		}
//		else if(source.equals("checkBal")) {
//			writer.println("<html><body>");
//	        writer.println("<h2>Your Balance: " + balance + "</h2>");
//	        writer.println("</body></html>");
//		
//		}
//		else {
//			writer.println("<html><body>");
//            writer.println("<h2>Invalid operation.</h2>");
//            writer.println("</body></html>");
//		}
		Hibernate_Utility.transaction.commit();
		
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("acManager.html");
		requestDispatcher.include(req, resp);
	}
	
	public void debitMoney(String SdebitAmt,HttpServletResponse resp, int balance,Customer user) throws IOException {
		PrintWriter writer = resp.getWriter();
		int debitAmt = Integer.parseInt(SdebitAmt);
			if(debitAmt!=0) {
				
			
			if(balance>=debitAmt) {
				balance= balance-debitAmt;
				user.setBalance(balance);
				writer.println("<html><body>");
	            writer.println("<script>"
	                    + "alert(`RS.${balance} DEBITED SUCCESSFULLY from your Account`);" 
	                    + "</script>");
	            writer.println("</body></html>");
	            
			}
			else {
				writer.println("<html><body>");
				writer.println("<script>"
	                    + "alert('Insufficient Balance !');" 
	                    + "</script>");
				writer.println("</body></html>");
			}
		}
	    }

	   
	
	public void creditMoney(String ScreditAmt,HttpServletResponse resp, int balance,Customer User) throws IOException {
		PrintWriter writer = resp.getWriter();
		int creditAmt = Integer.parseInt(ScreditAmt);
		if(creditAmt!=0) {
			balance= balance+creditAmt;
			User.setBalance(balance);
			writer.println("<html><body>");
           
            writer.println("<h2>RS." +creditAmt+"Has been Credited Successfully to you account</h2>");
            writer.println("</body></html>");
		}
	}
	public void transferMoney(String StransferAmt,String StransferAc,HttpServletResponse resp, int balance,Customer User) throws IOException{
		PrintWriter writer = resp.getWriter();
		int transferAmt = Integer.parseInt(StransferAmt);
		int transferAc = Integer.parseInt(StransferAc);
		
		if(transferAmt!=0 && transferAc!=0) {
			if(balance >=transferAmt) {
			balance = balance - transferAmt;
			User.setBalance(balance);
			 Customer findRecipent = Hibernate_Utility.entityManager.find(Customer.class, transferAc);
			 if(findRecipent!=null) {
			 int resipentBal = findRecipent.getBalance();
			 resipentBal = resipentBal+transferAmt;
			 findRecipent.setBalance(resipentBal);
			 writer.println("<html><body>");
             writer.println("<h2>RS." + transferAmt + " has been transferred successfully to account " + transferAc + "</h2>");
             writer.println("</body></html>");

             
			 }
			 else {
				 writer.println("<html><body>");
                    writer.println("<h2>Recipient account not found.</h2>");
                    writer.println("</body></html>");
			 }
			}
			else {
				writer.println("<html><body>");
                writer.println("<h2>Insufficient Balance !</h2>");
                writer.println("</body></html>");
			}
		}
	
	}
	public void checkBalance(HttpServletResponse resp, int balance) throws IOException {
		PrintWriter writer = resp.getWriter();
		writer.println("<html><body>");
        writer.println("<h2>Your Balance: " + balance + "</h2>");
        writer.println("</body></html>");
	}
}
