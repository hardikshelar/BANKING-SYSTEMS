package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Customer;
@WebServlet("/modify_user")
public class ModifyUser extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		String uId = req.getParameter("userId");
		String email = req.getParameter("email");
		String Fname = req.getParameter("full-name");
		String address = req.getParameter("address");
		String Phoneno = req.getParameter("phone-number");
		int phNo = Integer.parseInt(Phoneno);
		Customer findUserToModify = Hibernate_Utility.entityManager.find(Customer.class, Integer.parseInt(uId));
		if(findUserToModify!=null) {
		Hibernate_Utility.transaction.begin();
		findUserToModify.setEmail(email);
		findUserToModify.setFullName(Fname);
		findUserToModify.setAddress(address);
		findUserToModify.setPhoneNo(phNo);
		
		Customer updateUser = Hibernate_Utility.entityManager.merge(findUserToModify);
		writer.println("<html><body>");
        
        writer.println("<h2>Account Updated Successfully!</h2>");
        writer.println("</body></html>");
		
		Hibernate_Utility.transaction.commit();
		
		}
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("modify_user.jsp");
		requestDispatcher.include(req, resp);
	}
}
