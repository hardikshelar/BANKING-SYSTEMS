package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Customer;
@WebServlet(value = "/login")
public class Login extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String customerId = req.getParameter("customer-id");
		int cId = Integer.parseInt(customerId);
		String password = req.getParameter("password");
		
		HttpSession session = req.getSession();
		
		Customer registeredUser = Hibernate_Utility.entityManager.find(Customer.class, cId);
		PrintWriter writer = resp.getWriter();
		if (registeredUser != null && registeredUser.getCustomerId() != 0) {
			if (registeredUser.getCustomerId()==cId && registeredUser.getPassword().equals(password)) {

				session.setAttribute("cId", cId);	
				session.setAttribute("password", password);
				session.setMaxInactiveInterval(100);

				RequestDispatcher requestDispatcher = req.getRequestDispatcher("acManager.html");
				requestDispatcher.forward(req, resp);

			} else if (registeredUser.getCustomerId()== cId
					&& !registeredUser.getPassword().equals(password)) {
				
				writer.println("<html><body>");
				writer.println("<h2>Incorrect Password!</h2>");
				writer.println("</body></html>");
			}
		} else {
			
			writer.println("<html><body>");
			writer.println("<h2>No User Is Registered With This Credentials! Please Register First</h2>");
			writer.println("</body></html>");
		}
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("login.html");
		requestDispatcher.include(req, resp);
		
	}
}
