package edu.jsp.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspid.utility.Hibernate_Utility;

import edu.jsp.Model.Admin;
import edu.jsp.Model.Customer;


@WebServlet(value = "/register")
public class Register extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	String source = req.getParameter("source");
        String email = req.getParameter("email");
        String pass = req.getParameter("password");
        String fName = req.getParameter("full-name");
        String address = req.getParameter("address");
        String designation = req.getParameter("designation");
        String phoneNumber = req.getParameter("phone-number");
        int phNo = Integer.parseInt(phoneNumber);
        PrintWriter writer = resp.getWriter();
        
        List<Customer> findEmail = DataRetrieval.usernameRetrival(email);
        if (!findEmail.isEmpty()) {
            writer.println("<html><body>");
            writer.println("<script>"
                    + "alert('Username Already Registered !! Please Register With Another Username');" 
                    + "</script>");
            writer.println("</body></html>");
        } else {
            int newCustomerId = DataRetrieval.generateNewAccountNumber();

            
            if(source.equals("page1")) {
            	Hibernate_Utility.transaction.begin();
            Customer customer1 = new Customer(email, fName, address, phNo, pass);
            customer1.setCustomerId(newCustomerId);
            Admin findAdmin = Hibernate_Utility.entityManager.find(Admin.class, 1);
            List<Customer> customerList = findAdmin.getCustomer();
            customerList.add(customer1);
            Hibernate_Utility.entityManager.persist(customer1);
            Hibernate_Utility.transaction.commit();
            }
            else {
            	Hibernate_Utility.transaction.begin();
            	Admin admin = new Admin(email,fName,pass,designation,phNo);
            	
            	Hibernate_Utility.entityManager.persist(admin);
            	Hibernate_Utility.transaction.commit();
            }
            
            writer.println("<html><body>");
            writer.println("<script>"
                    + "alert('Successfully Registered !! Please Login!');" 
                    + "</script>");
            writer.println("</body></html>");
        }
        
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("Registration.html");
        requestDispatcher.include(req, resp);
    }
}
    

